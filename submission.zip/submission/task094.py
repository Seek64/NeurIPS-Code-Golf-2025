import re
def p(g):m=eval(re.sub("(%s.{79}1, 8, )8, 8, 1"%(5*"1, "),r"\1 6,8,1","%s"%g));return[[-(-r[i]|2*(6in(*r,*[*zip(*m)][i])))for i in range(15)]for r in m]