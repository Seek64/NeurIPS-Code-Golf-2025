import re
p=lambda g:[g:=eval(re.sub("(?<="+n*"5, "+n*((s:="5.{%d}5"%(34-3*n))+f", ){n*'0, '}(")+s+n*", 5"+")",n*(n*"2,"+r"\%d ")%(1,2,3,4)[:n],f"{g}"))for n in b""][4]